setTimeout(() => {
    window.location.href = '/PAGES/login.html';
  }, 3000);