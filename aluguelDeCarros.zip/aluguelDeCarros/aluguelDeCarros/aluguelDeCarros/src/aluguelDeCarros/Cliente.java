package aluguelDeCarros;

public class Cliente extends Usuario {
	
	private String cpf;
	
	// Construtor da classe Cliente
    public Cliente(long id, String nome, int contato, String cpf) {
        super(id, nome, contato);  // Passando parâmetros para o construtor da classe pai
        this.cpf = cpf;  // Inicializando o campo cpf na classe Cliente
    }

	
	
}
