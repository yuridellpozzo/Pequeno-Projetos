/**
 * 
 */
/**
 * @author Alunos
 *
 */
module aluguelDeCarros {
	requires java.sql;
}