package aluguelDeCarros;

public class Vendedor {
	long idVendedor;
	String nomeVendedor;
	int funcao; // logica verificação de perfil
	int contatoVendedor;
	
}
