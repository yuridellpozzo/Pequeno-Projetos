package aluguelDeCarros;

public class Usuario {
	private long id;
	private String nome;
	private int funcao; //0 - dono, 1 - vendedor
	private int contato;
	
	public Usuario(long id, String nome, int funcao, int contato) {
		super();
		this.id = id;
		this.nome = nome;
		this.funcao = funcao;
		this.contato = contato;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getFuncao() {
		return funcao;
	}

	public void setFuncao(int funcao) {
		this.funcao = funcao;
	}

	public int getContato() {
		return contato;
	}

	public void setContato(int contato) {
		this.contato = contato;
	}
	
	
	
	
	
}

