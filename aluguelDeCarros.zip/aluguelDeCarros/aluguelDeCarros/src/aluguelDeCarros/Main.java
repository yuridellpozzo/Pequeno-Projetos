package aluguelDeCarros;

import java.util.Scanner;

public class Main {

	private static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		 int opcao;

		        do {
		            System.out.println("=== MENU PRINCIPAL ===");
		            System.out.println("1 - Login");
		            System.out.println("2 - Cadastrar");
		            System.out.println("3 - Cliente");
		            System.out.println("4 - Carros");
		            System.out.println("5 - Aluguel");
		            System.out.println("6 - Caixa");
		            System.out.println("0 - Sair");
		            System.out.print("Escolha uma opção: ");
		            
		            // Lê a opção do usuário
		            opcao = scanner.nextInt();
		            scanner.nextLine(); // Limpa o buffer

		            switch (opcao) {
		                case 1:
		                    System.out.println("Você escolheu: Login");
		                    // Chamar método de login aqui
		                    break;
		                case 2:
		                    System.out.println("Você escolheu: Cadastrar");
		                    // Chamar método de cadastro aqui
		                    break;
		                case 3:
		                    System.out.println("Você escolheu: Cliente");
		                    // Chamar gerenciamento de cliente aqui
		                    break;
		                case 4:
		                    System.out.println("Você escolheu: Carros");
		                    // Chamar gerenciamento de carros aqui
		                    break;
		                case 5:
		                    System.out.println("Você escolheu: Aluguel");
		                    // Chamar processo de aluguel aqui
		                    break;
		                case 6:
		                    System.out.println("Você escolheu: Caixa");
		                    // Chamar controle de caixa aqui
		                    break;
		                case 0:
		                    System.out.println("Encerrando o sistema. Até logo!");
		                    break;
		                default:
		                    System.out.println("Opção inválida! Tente novamente.");
		                    break;
		            }

		            System.out.println(); // Linha em branco para espaçamento

		        } while (opcao != 0);

		        scanner.close();
		    }


		

	}


