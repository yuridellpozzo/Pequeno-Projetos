package aluguelDeCarros;

public class Dono {
	long idDono;
	String nomeDono;
	int funcao; // logica verificação de perfil
	int contatoDono;

}
