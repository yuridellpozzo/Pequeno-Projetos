package aluguelDeCarros;

import java.time.LocalDateTime;

public class Carros {
	long idCarro;
	String marca;
	String modelo;
	String cor;
	int anoFabricado;//
	String placa;
	LocalDateTime dataIda; // aqui está a variável do tipo data
	LocalDateTime dataVolta;
	double valorAluguel;
	
}
