package aluguelDeCarros;

public class Usuario {
	private long id;
	private String nome;
	private int funcao; //0 - dono, 1 - vendedor
	private int contato;
	protected int senha;
	private String perfil;
	
	
	public Usuario(long id, String nome, int funcao, int senha, int contato) {
		super();
		this.id = id;
		this.nome = nome;
		this.funcao = funcao;
		this.contato = contato;
		this.senha = senha;
		setPerfil();  // Define o perfil baseado na função
	}
	
	
	// Método para definir o perfil
    private void setPerfil() {
        if (this.funcao == 0) {
            this.perfil = "Dono";
        } else if (this.funcao == 1) {
            this.perfil = "Vendedor";
        } else {
            this.perfil = "Desconhecido";
        }
    }
    
 // Método para exibir os dados do usuário
    public void exibirDados() {
        System.out.println("ID: " + this.id);
        System.out.println("Nome: " + this.nome);
        System.out.println("Função: " + this.perfil);
        System.out.println("Contato: " + this.contato);
        System.out.println("Senha: " + this.senha);
    }

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getFuncao() {
		return funcao;
	}

	public void setFuncao(int funcao) {
		this.funcao = funcao;
	}

	public int getContato() {
		return contato;
	}

	public void setContato(int contato) {
		this.contato = contato;
	}
	
	public long getSenha() {
		return senha;
	}

	public void setSenha(int senha) {
		this.senha = senha;
	}
	
	
	
	
	
}

