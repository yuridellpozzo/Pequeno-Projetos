package aluguelDeCarros;

import java.util.ArrayList;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Main {
	/*
	private static ArrayList<Usuario> usuarios = new ArrayList<>();
	private static ArrayList<Cliente> cliente = new ArrayList<>();
	private static ArrayList<Carros> carros = new ArrayList<>();
*/
	
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		//Aluguel r = new Aluguel();
		System.out.println("resres");
		String idAluguel = scanner.nextLine();
		
		
		
		/*
		 int opcao;

		        do {
		            System.out.println("=== MENU PRINCIPAL ===");
		            System.out.println("1 - Login");
		            System.out.println("2 - Cadastrar");
		            System.out.println("3 - Cliente");
		            System.out.println("4 - Carros");
		            System.out.println("5 - Aluguel");
		            System.out.println("6 - Caixa");
		            System.out.println("0 - Sair");
		            System.out.print("Escolha uma opção: ");
		            
		            // Lê a opção do usuário
		            opcao = scanner.nextInt();
		            scanner.nextLine(); // Limpa o buffer

		            switch (opcao) {
		                case 1:
		                    System.out.println("Você escolheu: Login");
		                   realizarLogin();
		                    break;
		                case 2:
		                    System.out.println("Você escolheu: Cadastrar");
		                    // Chamar método de cadastro aqui
		                    cadastrarUsuario();
		                    break;
		                case 3:
		                    System.out.println("Você escolheu: Cliente");
		                    // Chamar gerenciamento de cliente aqui
		                    cadastrarCliente();
		                    break;
		                case 4:
		                    System.out.println("Você escolheu: Carros");
		                    // Chamar gerenciamento de carros aqui
		                    cadastrarCarros();
		                    break;
		                case 5:
		                    System.out.println("Você escolheu: Aluguel");
		                    // Chamar processo de aluguel aqui
		                    registrarAluguel();
		                    break;
		                case 6:
		                    System.out.println("Você escolheu: Caixa");
		                    // Chamar controle de caixa aqui
		                    break;
		                case 0:
		                    System.out.println("Encerrando o sistema. Até logo!");
		                    break;
		                default:
		                    System.out.println("Opção inválida! Tente novamente.");
		                    break;
		            }

		            System.out.println(); // Linha em branco para espaçamento

		        } while (opcao != 0);

		        scanner.close();
		        
	}

	static void realizarLogin() 
	{
		System.out.println("\n=== Login ===");
        System.out.print("Digite o ID: ");
        long id = scanner.nextLong();

        System.out.print("Digite a Senha: ");
        int senha = scanner.nextInt();

        // Verifica se existe um usuário com esse ID e senha
        Usuario usuarioEncontrado = null;
        for (Usuario usuario : usuarios) {
            if (usuario.getId() == id && usuario.getSenha() == senha) {
                usuarioEncontrado = usuario;
                break;
            }
        }

        // Exibe o resultado do login
        if (usuarioEncontrado != null) {
            System.out.println("\nLogin bem-sucedido!");
            System.out.println("Bem-vindo, " + usuarioEncontrado.getNome() + "!");
            usuarioEncontrado.exibirDados();
        } else {
            System.out.println("\nUsuário não encontrado ou senha incorreta.");
        }
		
	}
	
	static void cadastrarUsuario()
	{
		System.out.println("=== Cadastro de Usuários ===");

        // Entrada de dados
        System.out.print("Digite o ID: ");
        long id = scanner.nextLong();

        scanner.nextLine();  // Consumir a nova linha após o número

        System.out.print("Digite o Nome: ");
        String nome = scanner.nextLine();

        System.out.print("Digite a Função (0 para Dono, 1 para Vendedor): ");
        int funcao = scanner.nextInt();

        System.out.print("Digite o Contato (número): ");
        int contato = scanner.nextInt();

        System.out.print("Digite a Senha (número): ");
        int senha = scanner.nextInt();

        // Criação do usuário com os dados informados
        Usuario usuario = new Usuario(id, nome, funcao, contato, senha);

        // Exibir os dados cadastrados
        System.out.println("\nUsuário Cadastrado com Sucesso!");
        usuario.exibirDados();
	}
	
	static void cadastrarCliente()
	{
		System.out.println("=== Cadastro de Clientes ===");
		
		// Entrada de dados
        System.out.print("Digite o ID: ");
        long id = scanner.nextLong();

        scanner.nextLine();  // Consumir a nova linha após o número

        System.out.print("Digite o Nome: ");
        String nome = scanner.nextLine();

        System.out.print("Digite o CPF: ");
        String cpf = scanner.nextLine();

        System.out.print("Digite o Contato (número): ");
        int contato = scanner.nextInt();
        
		Cliente cliente = new Cliente(id, nome, cpf, contato);
	}
	
	static void cadastrarCarros()
	{
		 // Coletando os dados do carro
        System.out.println("Digite o ID do Carro:");
        long idCarro = scanner.nextLong();
        scanner.nextLine();  // Limpar o buffer do scanner

        System.out.println("Digite a Marca do Carro:");
        String marca = scanner.nextLine();

        System.out.println("Digite o Modelo do Carro:");
        String modelo = scanner.nextLine();

        System.out.println("Digite a Cor do Carro:");
        String cor = scanner.nextLine();

        System.out.println("Digite o Ano de Fabricação do Carro:");
        int anoFabricado = scanner.nextInt();
        scanner.nextLine();  // Limpar o buffer do scanner

        System.out.println("Digite a Placa do Carro:");
        String placa = scanner.nextLine();

        System.out.println("Digite o Valor do Aluguel:");
        double valorAluguel = scanner.nextDouble();

        // Criando o objeto Carros
        Carros carro = new Carros(idCarro, marca, modelo, cor, anoFabricado, placa, valorAluguel);

        // Exibindo os dados do carro
        System.out.println("\nDados do Carro:");
        carro.exibirDados();
	}
	
	static void registrarAluguel()
	{
		*/
	}
	
}
	
	
	

	


