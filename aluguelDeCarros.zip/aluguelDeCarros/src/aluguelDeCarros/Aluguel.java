package aluguelDeCarros;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

public class Aluguel extends Carros{
	long idAluguel;
    //public long idCarro;
    LocalDateTime dataIda;
    LocalDateTime dataVolta;
    
    void idAluguel() {
        
    }

    
    
    
    
    
/*

    public double calcularValorAluguel(double valorDiaria) {
        if (dataIda != null && dataVolta != null && !dataVolta.isBefore(dataIda)) {
            long dias = ChronoUnit.DAYS.between(dataIda, dataVolta);
            // Se for no mesmo dia, conta como 1 diária
            dias = dias == 0 ? 1 : dias;
            this.valorAluguel = valorDiaria * dias;
            return this.valorAluguel;
        } else {
            throw new IllegalArgumentException("Datas inválidas: data de volta deve ser igual ou posterior à data de ida.");
        }
    }*/
}
