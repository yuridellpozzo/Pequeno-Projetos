package aluguelDeCarros;

public class Carros {
     String idCarro;
     String marca;
     String modelo;
     String cor;
     int anoFabricado;
     String placa;
    
    private double valorAluguel;
    
    
    public void IdCarro() {
    	System.out.println("Ferrai");
    }
    
    
/*
    // Construtor
    public Carros(long idCarro, String marca, String modelo, String cor, int anoFabricado, String placa, double valorAluguel) 
    {
        this.idCarro = idCarro;
        this.marca = marca;
        this.modelo = modelo;
        this.cor = cor;
        this.anoFabricado = anoFabricado;
        this.placa = placa;
        this.valorAluguel = valorAluguel;
    }

    // Getters e Setters
    public long getIdCarro() {
        return idCarro;
    }

    public void setIdCarro(long idCarro) {
        this.idCarro = idCarro;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public int getAnoFabricado() {
        return anoFabricado;
    }

    public void setAnoFabricado(int anoFabricado) {
        this.anoFabricado = anoFabricado;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public double getValorAluguel() {
        return valorAluguel;
    }

    public void setValorAluguel(double valorAluguel) {
        this.valorAluguel = valorAluguel;
    }

    // Método para exibir os dados do carro
    public void exibirDados() {
        System.out.println("ID do Carro: " + this.idCarro);
        System.out.println("Marca: " + this.marca);
        System.out.println("Modelo: " + this.modelo);
        System.out.println("Cor: " + this.cor);
        System.out.println("Ano Fabricado: " + this.anoFabricado);
        System.out.println("Placa: " + this.placa);
        System.out.println("Valor do Aluguel: R$ " + this.valorAluguel);
    }*/
}

