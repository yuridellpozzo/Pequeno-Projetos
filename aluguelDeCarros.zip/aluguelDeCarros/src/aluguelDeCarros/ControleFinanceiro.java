package aluguelDeCarros;

public class ControleFinanceiro {
	double gasolinaCarro;
	double caixaEntrada;
	double caixaSaida;
	double caixaTotal;
	long idAluguel;
	double valorAluguel;
	
	public double renda (double caixaEntrada,double caixaSaida) {
		double caixaTotal = caixaEntrada - caixaSaida;
		this.caixaTotal += caixaTotal;
		return this.caixaTotal;
	}
	
	public double despesa (double gasolinaCarro,double caixaSaida) {
		caixaSaida = gasolinaCarro;
		this.caixaSaida += caixaSaida;
		return this.caixaSaida;
	}
	
	public double receita (double valorAluguel,double caixaEntrada) {
		caixaEntrada = valorAluguel;
		this.caixaEntrada += caixaEntrada;
		return this.caixaEntrada;
	}

}
