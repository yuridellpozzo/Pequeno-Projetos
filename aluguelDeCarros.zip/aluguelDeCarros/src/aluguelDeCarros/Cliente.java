package aluguelDeCarros;

public class Cliente {
	long idCliente;
	String nome;
	int contato;
	String cpf;
	
}
